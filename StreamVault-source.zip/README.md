# StreamVault — Zero-Database High-Performance Video Platform

A **production-grade, zero-database video streaming platform** built on modern Static
Site Generation. Content is managed as Git-backed flat JSON files, media streaming is
fully offloaded, and search runs entirely in the browser via WebAssembly. The result is
an edge-delivered site engineered for a **100/100 Lighthouse score** with **zero JavaScript
shipped by default**.

> Implements the *Engineering Architectural Specification: Zero-Database High-Performance
> Video Platform* end to end.

---

## Architecture at a glance

| Layer | Technology | Why |
| --- | --- | --- |
| **Core engine** | Astro (SSG, `output: static`) | Pre-compiles every page to static HTML/CSS at build time. Ships **0 KB JS** by default. |
| **Data layer** | Git Content Collections (flat JSON) | No SQL/NoSQL. Metadata lives in `src/content/videos/*.json`, Zod-validated at build. Runtime query latency = 0 ms. |
| **Admin / CMS** | Decap CMS (`git-gateway`) at `/admin` | Visual editor that commits JSON straight to GitHub, triggering the build hook. No backend API exposed. |
| **Media / streaming** | Offloaded embeds (`streama2z.com`) | Transcoding, ABR, storage & thumbnails handled externally. Our servers deliver static HTML only. |
| **Search** | Pagefind (static WASM index) | Chunked index built post-compile; sub-10 ms client-side queries, <10 KB over the wire. |
| **Edge delivery** | Cloudflare Pages / Vercel Edge | Global CDN, automatic SSL + DDoS mitigation, <50 ms responses. |

### Engineered solutions to zero-database bottlenecks

- **Dynamic Static Pagination Engine** — Astro's `paginate()` compiles clean, crawlable
  routes (`/category/technology/1`, `/2`, …) at build time with self-referential canonicals.
  No runtime `LIMIT`/`OFFSET`.
- **Client-Side Static Search** — Pagefind indexes the built HTML into microscopic WASM
  chunks; titles, tags & categories are searchable instantly with no backend.
- **Static Graph Relation Matching (Related Videos)** — related content is computed at build
  time by scoring shared subcategory / category / tags (`src/utils/content.js → findRelated`)
  and embedded directly into the HTML.
- **Click-to-Play Facade Pattern** — watch pages render only a lightweight poster + button;
  the heavy third-party `<iframe>` is injected **only on explicit user click**, protecting
  LCP and INP/FID. *(Verified: 0 iframes on load → 1 on click.)*

---

## Project structure

```
video-platform/
├── astro.config.mjs            # SSG config, clean URLs, sitemap integration
├── src/
│   ├── content.config.ts       # Zod schema for the flat-file "database"
│   ├── config/site.ts          # Brand, SEO constants, taxonomy, page size
│   ├── content/videos/*.json   # The data — one JSON file per video
│   ├── layouts/BaseLayout.astro# <head>, SEO, canonical, OG, JSON-LD, header/footer
│   ├── components/
│   │   ├── Header.astro         VideoCard.astro
│   │   ├── Footer.astro         VideoFacade.astro   # click-to-play facade
│   ├── pages/
│   │   ├── index.astro                         # homepage (featured + latest)
│   │   ├── search.astro                        # noindex Pagefind search
│   │   ├── 404.astro
│   │   ├── watch/[slug].astro                  # watch page: facade + VideoObject + related
│   │   └── category/[category]/
│   │        ├── [page].astro                   # paginated category route
│   │        └── index.astro                    # bare → /1 redirect
│   ├── styles/global.css       # design system (dark theme, responsive, a11y)
│   └── utils/                  # content.js (pure helpers) + queries.js (data access)
├── public/
│   ├── admin/                  # Decap CMS (index.html + config.yml)
│   ├── robots.txt  favicon.svg  og-default.svg  _headers
├── scripts/
│   ├── build-video-sitemap.mjs # emits dist/sitemap-video.xml (Google Video sitemap)
│   └── generate-sample-data.mjs# seeds 24 realistic sample videos
├── .github/workflows/deploy.yml
├── vercel.json                 # Vercel build + caching/security headers
└── package.json
```

---

## Getting started

> **Requirements:** Node **>= 22.12** (Astro 7). Cloudflare Pages / Vercel already default
> to Node 22. Locally, use `nvm install 22 && nvm use 22`.

```bash
npm install
npm run seed      # optional: generate 24 sample videos to see it populated
npm run dev       # http://localhost:4321
```

### Build (SSG + search index + video sitemap)

```bash
npm run build     # astro build → pagefind index → video sitemap
npm run preview   # serve the production build locally
```

The `build` script runs three stages in order:

1. `astro build` — pre-renders all pages to `dist/`.
2. `pagefind --site dist` — indexes the built HTML into `dist/pagefind/`.
3. `node scripts/build-video-sitemap.mjs` — writes `dist/sitemap-video.xml`.

---

## Content model

Each video is a single JSON document in `src/content/videos/[slug].json`, validated by the
Zod schema in `src/content.config.ts`. A malformed record **fails the build** instead of
shipping a broken page.

```json
{
  "id": "vid_0001",
  "title": "Building a Zero-Database Video Platform with Astro",
  "slug": "building-a-zero-database-video-platform-with-astro",
  "description": "…",
  "category": "Technology",
  "subcategory": "AI & ML",
  "tags": ["astro", "ssg", "performance"],
  "duration": "PT22M35S",
  "publishedDate": "2026-05-13T10:33:58.271Z",
  "streamEmbedUrl": "https://streama2z.com/embed/…",
  "thumbnailUrl": "https://…/640/360",
  "featured": true
}
```

### Editing content

- **Visually:** deploy and visit `/admin` (Decap CMS). It commits JSON to Git → CI rebuilds.
  For local editing run `npx decap-server` (the config has `local_backend: true`).
- **By hand:** drop a new `.json` file into `src/content/videos/`.

---

## SEO & indexation strategy

- **Self-referential canonicals** on every watch page and category route (kills duplicate-content flags).
- **`VideoObject` + `BreadcrumbList` JSON-LD** on watch pages for Google Rich Results; `WebSite`
  + `ItemList` schemas elsewhere.
- **`rel="prev"/"next"`** on paginated series.
- **Interior search is `noindex,follow`** to avoid soft-duplicate penalties.
- **Two sitemaps:** the standard `sitemap-index.xml` (pages) and a dedicated Google Video
  sitemap at `sitemap-video.xml`. Both are referenced in `robots.txt`. Submit them in Google
  Search Console.

---

## Deployment

Set **`PUBLIC_SITE_URL`** to your production origin (used for canonicals, OG tags, and both
sitemaps) in the host's build environment.

### Cloudflare Pages
- Build command: `npm run build`
- Output directory: `dist`
- Env var: `PUBLIC_SITE_URL=https://your-domain`
- Caching/security headers are provided in `public/_headers`.

### Vercel
- Auto-detected via `vercel.json` (build, output, clean URLs, headers).
- Add `PUBLIC_SITE_URL` in Project → Settings → Environment Variables.

### Decap CMS auth
The CMS uses **git-gateway**. On Cloudflare/Vercel, wire up an OAuth provider (e.g. GitHub
OAuth app or Netlify Identity–compatible gateway) so `/admin` can authenticate and commit.

---

## Performance & verification notes

- **Zero JS by default:** the built `dist/_astro` contains **0 JS bundles**; the only scripts
  are the tiny inline facade handler (watch pages) and the JSON-LD blocks.
- **Facade verified:** automated check confirms `0 → 1` iframe transition on click with the
  correct embed URL.
- **Search verified:** client-side Pagefind query returns results from the WASM index with no
  backend.
- **Clean URLs:** canonicals resolve to `/watch/slug` and `/category/name/1` (no `.html`).
- `npm audit` → **0 vulnerabilities**.

---

## License

MIT — see project owner.
