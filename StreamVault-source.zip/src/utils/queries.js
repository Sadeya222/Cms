/**
 * Central data-access layer over the flat-file content collection.
 * Every page imports from here so sorting/normalisation logic lives in one place.
 */
import { getCollection } from 'astro:content';
import { categorySlug } from './content.js';

/**
 * Return all videos flattened to their data payload plus a stable `_slug`,
 * sorted newest-first. Cached within a single build via module scope.
 */
let _cache = null;
export async function getAllVideos() {
  if (_cache) return _cache;
  const entries = await getCollection('videos');
  _cache = entries
    .map((entry) => ({ ...entry.data }))
    .sort((a, b) => new Date(b.publishedDate).getTime() - new Date(a.publishedDate).getTime());
  return _cache;
}

/** Distinct category names, preserving first-seen order. */
export async function getCategories() {
  const videos = await getAllVideos();
  return [...new Set(videos.map((v) => v.category))];
}

/** Map of categorySlug -> { name, count }. */
export async function getCategoryIndex() {
  const videos = await getAllVideos();
  const map = new Map();
  for (const v of videos) {
    const slug = categorySlug(v.category);
    const existing = map.get(slug) || { name: v.category, slug, count: 0 };
    existing.count += 1;
    map.set(slug, existing);
  }
  return [...map.values()].sort((a, b) => a.name.localeCompare(b.name));
}

/** Featured videos for the homepage hero rail (falls back to newest). */
export async function getFeatured(limit = 6) {
  const videos = await getAllVideos();
  const featured = videos.filter((v) => v.featured);
  return (featured.length ? featured : videos).slice(0, limit);
}
