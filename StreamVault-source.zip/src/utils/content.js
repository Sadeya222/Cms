/**
 * Pure, build-time utility functions. No runtime dependencies, no side effects.
 */

/**
 * Convert an ISO 8601 duration (e.g. "PT1H08M15S") into a human label
 * ("1:08:15") and a total-seconds count. Used for UI + VideoObject schema.
 */
export function parseISODuration(iso) {
  const match = /^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/.exec(iso || '');
  if (!match) return { label: '', seconds: 0 };
  const [, h, m, s] = match.map((x) => (x ? Number(x) : 0));
  const seconds = h * 3600 + m * 60 + s;
  const pad = (n) => String(n).padStart(2, '0');
  const label = h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
  return { label, seconds };
}

/** URL-safe category slug (Technology -> technology). */
export function categorySlug(category) {
  return String(category)
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

/** Format an ISO timestamp for display, locale-stable across build machines. */
export function formatDate(iso) {
  return new Date(iso).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    timeZone: 'UTC',
  });
}

/**
 * Static Graph Relation Matching (Related Videos Engine).
 *
 * Replaces runtime DB joins / vector similarity with a deterministic, build-time
 * relevance score:
 *   +5  same subcategory
 *   +3  same primary category
 *   +2  per shared tag
 * Ties break by most-recent publishedDate for freshness.
 */
export function findRelated(current, all, limit = 6) {
  const currentTags = new Set((current.tags || []).map((t) => t.toLowerCase()));

  return all
    .filter((v) => v.id !== current.id)
    .map((v) => {
      let score = 0;
      if (v.category === current.category) score += 3;
      if (v.subcategory === current.subcategory) score += 5;
      for (const tag of v.tags || []) {
        if (currentTags.has(tag.toLowerCase())) score += 2;
      }
      return { video: v, score };
    })
    .filter((x) => x.score > 0)
    .sort(
      (a, b) =>
        b.score - a.score ||
        new Date(b.video.publishedDate).getTime() - new Date(a.video.publishedDate).getTime()
    )
    .slice(0, limit)
    .map((x) => x.video);
}

/** Truncate text for meta descriptions / cards without breaking words. */
export function truncate(text, max = 160) {
  if (!text || text.length <= max) return text;
  return text.slice(0, text.lastIndexOf(' ', max)).trimEnd() + '…';
}
